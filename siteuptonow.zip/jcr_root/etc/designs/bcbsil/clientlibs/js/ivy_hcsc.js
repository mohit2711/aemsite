$(document).ready(function(){

  slCheck($(window).width());

  var resizeTimer;

  $(window).on('resize', function(e) {

    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {

      slCheck($( window ).width());

    }, 250);

  });



  function slCheck(newSize){

  console.log('window size is: ' + newSize);

  if(newSize > 767){
      
      if(isEspanolSite()) {
		//hide floating Head, if present
		if($('#floatingHead').length > 0) {
			$("#floatingHead").hide();
			$("#floatingHead").css({"display":"none"});
		}
		  
        $('.ivy-image').attr("src", "/images/bcbs/redesign/ivy/es/banner.png");	
        /*appendCSS("/css/bcbs/redesign/ivy/es/VirtuOzhcscES.css");
        appendCSS("/css/bcbs/redesign/ivy/es/preprod.css");
        appendJS("/js/bcbs/redesign/ivy/es/parameters.js");
        appendJS("/js/bcbs/redesign/ivy/es/VirtuOzLoader.js");*/
        $("#ivy_hcsc_id").attr("onclick","Nina.AgentLoader.loadAgent('hcscES');");
        console.log("spanish");	
        
      } else {
        /*appendCSS("/css/bcbs/redesign/ivy/en/VirtuOzhcsc.css");				
        appendCSS("/css/bcbs/redesign/ivy/en/preprod.css");
        appendJS("/js/bcbs/redesign/ivy/en/VirtuOzLoader.js");
        appendJS("/js/bcbs/redesign/ivy/en/parameters.js");*/
        $("#ivy_hcsc_id").attr("onclick","Nina.AgentLoader.loadAgent('hcscEN');");
        console.log("english");
      }
  

      }	else {
				$("#hcscES").hide();
				$("#hcscES").css({"display":"none"});
				console.log('mobile or tablet view, hide popin');
			}
			
			
			
			/*else {
			if(isEspanolSite() && $('#hcscES').length > 0) {
				$("#hcscES").hide();
				$("#hcscES").css({"display":"none"});
			} else if($('#hcscEN').length > 0){
				$("#hcscEN").hide();
				$("#hcscEN").css({"display":"none"});
			}
			console.log('mobile or tablet view, hide popin')

      }*/

  } 

});
		
function isEspanolMobileSite(){
	var url = window.location.href;
	if(url.indexOf("espanol") > -1) {  //add more specific condition
		return true;
	}else{
		return false;
	}
}	
function isEspanolSite(){
	var url = window.location.href;
	if(url.indexOf("espanol") > -1) {  //add more specific condition
		return true;
	}else{
		return false;
	}
}		
function appendJS(urlJS){
		var e = document.createElement("script");
		e.src = urlJS;
		e.type="text/javascript";
		e.async = true;
		e.onerror = function(){ delete me.loadingList[id]; };
		var s = document.getElementsByTagName("script")[0];
		s.parentNode.insertBefore(e,s);
}
function appendCSS(urlCSS){
		var e = document.createElement("link");
		e.rel = "stylesheet";
		e.type = "text/css";
		e.href = urlCSS;
		e.media = "all";
		document.getElementsByTagName("head")[0].appendChild(e);          
}