//var mobileDevice = "false";

// Mobile Device detection logic
/*if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/Blackberry/i)) || ( (navigator.userAgent.match(/Android/i)) && (navigator.userAgent.match(/Mobile/i)) ) || (navigator.userAgent.match(/Windows CE/i)) || (navigator.userAgent.match(/Palm/i)) || (navigator.userAgent.match(/Windows Phone/i))  ) {
mobileDevice = "true";
} */

function submitSHOP() {
$("#returning_shop_login").attr("action","https://retailweb.hcsc.net/retailshoppingcart/public/login");
document.getElementById('returning_shop_login').submit();
//return false;
}

function submitSHOPMobile() {
$("#returning_shop_login_mobile").attr("action","https://retailweb.hcsc.net/retailshoppingcart/public/login");
document.getElementById('returning_shop_login_mobile').submit();
//return false;
}


function submitBamok() {
$("#BamLogin").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=OK1&cmdAction=doLogin");
document.getElementById('BamLogin').submit();
//return false;
}

function submitBamokMobile() {
$("#BamLoginmobile").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=OK1&cmdAction=doLogin");
document.getElementById('BamLoginmobile').submit();
//return false;
}


function submitBamtx() {
$("#BamLogin").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=TX1&cmdAction=doLogin");
document.getElementById('BamLogin').submit();
//return false;
}

function submitBamtxMobile() {
$("#BamLoginmobile").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=TX1&cmdAction=doLogin");
document.getElementById('BamLoginmobile').submit();
//return false;
}


function submitBamnm() {
$("#BamLogin").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=NM1&cmdAction=doLogin");
document.getElementById('BamLogin').submit();
//return false;
}

function submitBamnmMobile() {
$("#BamLoginmobile").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=NM1&cmdAction=doLogin");
document.getElementById('BamLoginmobile').submit();
//return false;
}

function submitBamMT() {
$("#BamLogin").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=MT1&cmdAction=doLogin");
document.getElementById('BamLogin').submit();
//return false;
}

function submitBamMTMobile() {
$("#BamLoginmobile").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=MT1&cmdAction=doLogin");
document.getElementById('BamLoginmobile').submit();
//return false;
}

function submitBam() {
$("#BamLogin").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=IL1&cmdAction=doLogin");
document.getElementById('BamLogin').submit();
//return false;
}

function submitBamMobile() {
$("#BamLoginmobile").attr("action","https://members.hcsc.net/wps/PA_BAMLogin/bamGateway?corpEntCode=IL1&cmdAction=doLogin");
document.getElementById('BamLoginmobile').submit();
//return false;
}



function submitSHOPPER() {
$("#returning_shopper_login").attr("action","https://retailweb.hcsc.net/retailshoppingcart/public/login");
document.getElementById('returning_shopper_login').submit();

//return false;
}

function submitSHOPPERMobile() {
$("#returning_shopper_login_mobile").attr("action","https://retailweb.hcsc.net/retailshoppingcart/public/login");
document.getElementById('returning_shopper_login_mobile').submit();
//return false;
}


function submitBAEilSM() {
$("#BAELogin").attr("action","https://login.bcbsil.com/siteminderagent/forms/login.fcc");
document.getElementById('BAELogin').submit();
//return false;
}

function submitBAE() {
$("#BAELogin").attr("action","https://employersportal.hcsc.net/employers/login/il?action=login");
document.getElementById('BAELogin').submit();
//return false;
}

function submitBAEMobile() {
$("#BAELoginmobile").attr("action","https://employersportal.hcsc.net/employers/login/il?action=login");
document.getElementById('BAELoginmobile').submit();
//return false;
}

function submitBAEmtSM() {
$("#BAELogin").attr("action","https://login.bcbsmt.com/siteminderagent/forms/login.fcc");
document.getElementById('BAELogin').submit();
//return false;
}

function submitBAEmt() {
$("#BAELogin").attr("action","https://employersportal.hcsc.net/employers/login/mt?action=login");
document.getElementById('BAELogin').submit();
//return false;
}

function submitBAEmtMobile() {
$("#BAELoginmobile").attr("action","https://employersportal.hcsc.net/employers/login/mt?action=login");
document.getElementById('BAELoginmobile').submit();
//return false;
}

function submitBAEnmSM() {
$("#BAELogin").attr("action","https://login.bcbsnm.com/siteminderagent/forms/login.fcc");
document.getElementById('BAELogin').submit();
//return false;
}

function submitBAEnm() {
$("#BAELogin").attr("action","https://employersportal.hcsc.net/employers/login/nm?action=login");
document.getElementById('BAELogin').submit();
//return false;
}

function submitBAEnmMobile() {
$("#BAELoginmobile").attr("action","https://employersportal.hcsc.net/employers/login/nm?action=login");
document.getElementById('BAELoginmobile').submit();
//return false;
}

function submitBAEokSM() {
$("#BAELogin").attr("action","https://login.bcbsok.com/siteminderagent/forms/login.fcc");
document.getElementById('BAELogin').submit();

//return false;
}


function submitBAEok() {
$("#BAELogin").attr("action","https://employersportal.hcsc.net/employers/login/ok?action=login");
document.getElementById('BAELogin').submit();

//return false;
}

function submitBAEokMobile() {
$("#BAELoginmobile").attr("action","https://employersportal.hcsc.net/employers/login/ok?action=login");
document.getElementById('BAELoginmobile').submit();
//return false;
}

function submitBAEtxSM() {
$("#BAELogin").attr("action","https://login.bcbstx.com/siteminderagent/forms/login.fcc");
document.getElementById('BAELogin').submit();

//return false;
}


function submitBAEtx() {
$("#BAELogin").attr("action","https://employersportal.hcsc.net/employers/login/tx?action=login");
document.getElementById('BAELogin').submit();

//return false;
}

function submitBAEtxMobile() {
$("#BAELoginmobile").attr("action","https://employersportal.hcsc.net/employers/login/tx?action=login");
document.getElementById('BAELoginmobile').submit();
//return false;
}


function submitBAP() {
  var x = document.forms["BAPLogin"]["userId"].value;
  var y = document.forms["BAPLogin"]["pswd"].value;
  if (x == null || x == "" || y == null || y =="") {
        alert("Please enter both Producer Name and Password.");
        return false;
    }

  else {
$("#BAPLogin").attr("action","https://producers.hcsc.net/producers/j_security_check");
document.getElementById('BAPLogin').submit();

		 }
//return false;
}


function submitBAPMobile() {
   var x = document.forms["BAPLoginmobile"]["userId"].value;
   var y = document.forms["BAPLoginmobile"]["pswd"].value;
   if (x == null || x == "" || y == null || y =="") {
        alert("Please enter both Producer Name and Password.");
        return false;
    }
	
  else {
$("#BAPLoginmobile").attr("action","https://producers.hcsc.net/producers/j_security_check");
document.getElementById('BAPLoginmobile').submit();

		 }
//return false;
}


