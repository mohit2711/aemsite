// CHANGE SHOWALERT VALUE TO EITHER "ON" OR "OFF"

var show_alert = "on";

var show_bam = "on";

var show_shopbyprice = "off";



var now = new Date();

var dayNames = new 

Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

var thisday = dayNames[now.getDay()];

var thismonth = now.getMonth() + 1;

var thisdate = now.getDate();





// THIS WILL COMMENT OUT THE ENTIRE ALERT MESSAGE IF SHOW_ALERT IS OFF

if (show_alert == "off") {

	document.write('<!--');

}



if ((show_alert == "on") && (show_bam == "on")) {

	if ((thismonth == 10) && (thisdate == 20)) {  // July 1.  Also can use "thisday" to filter by day of week

		if ((now.getHours() >= 3) && (now.getHours() <= 5)){ 

			bamDown();

		}

	}

	if ((thismonth == 6) && (thisdate == 8)) {  // July 1.  Also can use "thisday" to filter by day of week

		if (now.getHours() <= 1){ 

			bamDown();

		}

	}

}

 



if ((show_alert == "on") && (show_shopbyprice == "on")) {

	if ((thismonth == 1) && (thisdate == 20)) {  // July 1.  Also can use "thisday" to filter by day of week

		if ((now.getHours() >= 19) && (now.getHours() <= 23)){ 

// SHOP BY PRICE ALERT

	// IL, TX and OK alert message

	document.write('<style>.np_bg p.intro {display:none}.state_alert, .nm_alert{font-weight:bold;color:#ff0000}</style>');	

	document.write('<span class="hp_alert state_alert">');

	document.write('Our individual and family plan pricing system will undergo routine maintenance beginning at 8pm - 12am on Saturday, August 18. Quotes may be unavailable during this time. We apologize for any inconvenience.');

	document.write('</span>');

	

	// New Mexico alert message

	document.write('<span class="hp_alert nm_alert">');

	document.write('Our individual and family plan pricing system will undergo routine maintenance beginning at 7pm - 11pm on Fiday, August 17. Quotes may be unavailable during this time. We apologize for any inconvenience.');

	document.write('</span>');

		}

	}

}



// THIS WILL CLOSE OUT THE COMMENT IF SHOW_ALERT IS OFF

if (show_alert == "off") {

	document.write('-->');

}


