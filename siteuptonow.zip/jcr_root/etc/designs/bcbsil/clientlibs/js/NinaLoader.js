
/**
 * Copyright 2010-2013 Nuance Communications Inc. All rights reserved.
 */

/**
 * @namespace
 */
window.Nina = window.Nina || {};
window.NinaVars = window.NinaVars || {};
/**
 * @namespace
 */
window.Nina.AgentLoader = function() {
	"use strict";
    var me = {}, NinaVars = window.NinaVars;
    me.loaderFileName = "js/bcbs/redesign/ivy/NinaLoader.js";
    me.loaded = {};
    me.loaded.name = "";
    me.proactiveLaunch = (NinaVars.hasOwnProperty("proactiveLaunch") && typeof NinaVars.proactiveLaunch.agentName === "string" && typeof NinaVars.proactiveLaunch.delay === "number");
    me.proactivityTimerId = null;
    me.loadingList = {};

    // First check if we have any agent session cookie. If it exists, we trigger the loading of the main js
    var pattern = /^Nina-.+-session$/;
    /*only cookies for this domain and path will be retrieved */
    var cookieJar = document.cookie.split( "; " );
    for( var x = 0; x < cookieJar.length; x++ ) {
        var oneCookie = cookieJar[x].split( "=" );
        if( oneCookie[0].search(pattern) === 0 && oneCookie[1].indexOf("popinState") !== -1) {
            // We have a live session cookie, so we'll be loading the corresponding js
            load(oneCookie[0].substr(5,oneCookie[0].length-13)); // cookie_name = Nina-agentname-session. We keep "agentname"
            me.proactiveLaunch = false;
        }
    }
    if(me.proactiveLaunch){
        loadAfter(NinaVars.proactiveLaunch.agentName, NinaVars.proactiveLaunch.delay);
    }
    /**
     * Show the agent whose id is requested. If not already loaded, load it. Otherwise, just call the show method
     * @param {string} id
     * @returns {void}
     */
    function load(id, options) {
        options = options || {};
        if(me.loaded.name === id) {
            // Already loaded this one, need to call method that shows the virtual agent
            me.loaded.popin.show();
            return;
        } else if(me.loaded.popin && me.loaded.popin !== null && me.loaded.popin.hide && typeof me.loaded.popin.hide === "function") {
            me.loaded.popin.hide();
        }
        //In case the user opened the popin while a proactivityTimer was on, we stop it.
        if(typeof me.proactivityTimerId === "number"){
            window.clearTimeout(me.proactivityTimerId);
        }
        if(!me.loadingList.hasOwnProperty(id)){
            //we put a lock to prevent multiple loading
            if(options.lock) {
                me.loadingList[id] = true;
            }
            /**
             * If the proactive launch is active or if the opener param is set,
             * we set the action that opened the popin : NinaVars.opener = opener|"user"
             */
            if(options.hasOwnProperty("opener")){
                NinaVars.opener = options.opener;
            }

            // Load asynchronously. Once support for async attribute is generalized we can remove that but for now,
            // timeout is the best bet.
            var baseDir = getScriptPath(me.loaderFileName);
						
						
						var idLang=id.substring(4);
						idLang=idLang.toLowerCase();
			
			var cssPath = "/css/bcbs/redesign/ivy/en";
            var jsPath = "/js/bcbs/redesign/ivy/en";
            if(isEspanolSite()) {
                cssPath = "/css/bcbs/redesign/ivy/es";
                jsPath = "/js/bcbs/redesign/ivy/es";
            }
            
            if(isEspanolSite() && id==="hcscES" && $(window).width() > 767) {
            // Insert CSS
            var e = document.createElement("link");
            e.rel = "stylesheet";
            e.type = "text/css";
            e.href = baseDir + "css/bcbs/redesign/ivy/" + idLang + "/" + id + ".css";
            e.media = "all";
            document.getElementsByTagName("head")[0].appendChild(e);

            // Insert JS
						
            e = document.createElement("script");
            e.src = baseDir + "js/bcbs/redesign/ivy/" + idLang + "/" + id + ".js";
            e.type="text/javascript";
            e.async = true;
            e.onerror = function(){ delete me.loadingList[id]; };
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(e,s);
           } else if(!isEspanolSite() && id==="hcscEN" && $(window).width() > 767) {
                // Insert CSS
                var e = document.createElement("link");
                e.rel = "stylesheet";
                e.type = "text/css";
                e.href = baseDir + "css/bcbs/redesign/ivy/" + idLang + "/" + id + ".css";
                e.media = "all";
                document.getElementsByTagName("head")[0].appendChild(e);
 
                // Insert JS
                e = document.createElement("script");
                e.src = baseDir + "js/bcbs/redesign/ivy/" + idLang + "/" + id + ".js";
                e.type="text/javascript";
                e.async = true;
                e.onerror = function(){ delete me.loadingList[id]; };
                var s = document.getElementsByTagName("script")[0];
                s.parentNode.insertBefore(e,s);
            } 
        }//else it's locked, the JS is loading and the popin is not registered yet (me.loaded.name)
    }
    /**
     * Show the agent whose id is requested after s seconds. If not already loaded, load it. Otherwise, just call the show method
     * @param {string} id
     * @returns {void}
     */
    function loadAfter(id, delay){
        me.proactivityTimerId = window.setTimeout(function(){
            load(id, { opener: "proactive" });
        }, delay*1000);
    }
    
    function isEspanolSite(){
        var url = window.location.href;
        if(url.indexOf("espanol") > -1) {  //add more specific condition
            return true;
        }else{
            return false;
        }
    }  

    /**
     * Retrieves the base path of the location the agent files are stored in
     * @param {string} scriptname
     * @returns {string}
     */
	function getScriptPath(scriptname){
		scriptname = scriptname.toLowerCase();
		var scriptobjects = document.getElementsByTagName('script');
		for (var i=0; i<scriptobjects.length; i++) {
			if(scriptobjects[i].src && scriptobjects[i].src.toLowerCase().lastIndexOf(scriptname) !== -1){
				return scriptobjects[i].src.toString().substring(0, scriptobjects[i].src.toLowerCase().lastIndexOf(scriptname));
			}
		}
		return null;
	}

    return {
        /**
         * This function will display the virtual agent whose id is provided.
         * @param {string} id The id of the virtual agent we want to display
         * @param {object} options Contains properties like "opener" (optional)
         * @returns {void}
         */
        loadAgent: function(id, options) {
            var o = options || {};
            o.lock = true;
            load(id, options);
        },
        /**
         * This function is used by the popin module to indicate it has initialized and provide access to its functions
         * to the NinaLoader module
         * @param {string} id The id of the virtual agent
         * @param {Object} popinFunctions Object containing the popin display functions (show, hide, minimize)
         * @returns {void}
         */
        setAgentPopin: function(id, popinFunctions) {
            me.loaded.name = id;
            me.loaded.popin = popinFunctions;
        },
        /**
         * This function returns the base url where the NinaLoader module is located. It's used by other modules in the case the
         * page embedding the agent is not in the same directory as the agent.
         * @returns {string}
         */
        getBaseDir: function() {
            return getScriptPath(me.loaderFileName);
        }

    };
}();
