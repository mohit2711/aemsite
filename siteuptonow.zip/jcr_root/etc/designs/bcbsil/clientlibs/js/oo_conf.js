/*
OnlineOpinion v5.6.7
Released: 2/4/2013. Compiled 02/05/2013 11:23:54 AM -0600
Branch: master fa7a9ce586575d15a239edd08ee08c20a6286836
Components: Full
The following code is Copyright 1998-2013 Opinionlab, Inc.  All rights reserved. Unauthorized use is prohibited. This product and other products of OpinionLab, Inc. are protected by U.S. Patent No. 6606581, 6421724, 6785717 B1 and other patents pending. http://www.opinionlab
*/

/* Inline configuration */
  var oo_feedback = new OOo.Ocode({});

